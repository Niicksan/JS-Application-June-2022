async function solution() {
    const main = document.getElementById('main');

    // create fragment
    const fragment = document.createDocumentFragment();

    // get all articles from the database
    const articles = await request('http://localhost:3030/jsonstore/advanced/articles/list');

    // get all created containers as promises
    const containersAsPromises = articles.map(createElement);

    // resolve all promises -> return an array with div elements
    const containerArray = await Promise.all(containersAsPromises)

    // append all articles to the fragment
    containerArray.forEach(a => fragment.appendChild(a));

    // append all article in the fragment to the main
    main.replaceChildren(fragment);

    // create article container for every article
    async function createElement(profile) {
        // crete main container
        const div = document.createElement('div');
        div.classList.add('accordion');
        div.innerHTML = ` 
            <div class="head">
                <span>${profile.title}</span>
                <button class="button" id="${profile._id}">More</button>
            </div>
        `;

        // fetch article by id
        const article = await request(`http://localhost:3030/jsonstore/advanced/articles/details/${profile._id}`);

        // create extra container
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('extra');
        contentDiv.innerHTML = `
            <p>${article.content}</p>
        `

        // add functionality to the button
        const moreButton = div.querySelector('.button');
        moreButton.addEventListener('click', showMore);

        div.appendChild(contentDiv);
        return div;

        function showMore(e) {
            if (moreButton.textContent === 'More') {
                moreButton.textContent = 'Less';
                contentDiv.style.display = 'block'
            } else {
                moreButton.textContent = 'More';
                contentDiv.style.display = 'none';
            }
        }
    }

    // fetch function
    async function request(url) {
        try {
            const response = await fetch(url);

            if (!response.ok) {
                throw new Error('Error');
            }

            return await response.json();

        } catch (error) {
            alert(error.message);
        }
    }
}

window.onload = solution();